#include "View/View.h"
#include <iostream>

using std::cin;
using std::cout;
using std::endl;

int main()
{
    // Objeto de tipo View para enlazar con la vista
    View vistaPPAL;
    vistaPPAL.verPrincipal();
    return 0;
}