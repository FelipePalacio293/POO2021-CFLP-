#include "View/View.h"

int main()
{
    // Objeto de tipo View para enlazar con la vista
    View vistaPPAL;
    vistaPPAL.verPrincipal();
    return 0;
}